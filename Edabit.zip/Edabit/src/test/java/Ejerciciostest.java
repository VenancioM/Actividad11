

import metodos.Ejercicios;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Ejerciciostest {
    //addition
    @Test
    public void test1() {
        System.out.println("2 plus 1 equals 3");
        assertEquals(3,Ejercicios.addition(2));
    }
    
    @Test
    public void test2(){
        System.out.println("-8 plus 1 equals 9");
        assertEquals(-8,Ejercicios.addition(-9));
    }
    
    @Test
    public void test3(){
        System.out.println("0 plus 1 equals 1");
        assertEquals(1,Ejercicios.addition(0));
    }
    
    @Test
    public void test4(){
        System.out.println("999 plus 1 equals 1000");
        assertEquals(1000,Ejercicios.addition(999));
    }
    
    @Test
    public void test5(){
        System.out.println("73 plus 1 equals 74");
        assertEquals(74, Ejercicios.addition(73));
    }
    
    //isEqual
    @Test
    public void test6(){
        assertEquals(true, Ejercicios.isEqual(2, 2));
    }
    
    @Test
    public void test7(){
        assertEquals(true, Ejercicios.isEqual(88, 88));
    }
    
    @Test
    public void test8(){
        assertEquals(false, Ejercicios.isEqual(36, 35));
    }
    
    @Test
    public void test9(){
        assertEquals(true, Ejercicios.isEqual(1, 1));
    }
    
    @Test
    public void test10(){
        assertEquals(false, Ejercicios.isEqual(5, 6));
    }
    
    //remainder
    @Test
    public void test11(){
        assertEquals(1, Ejercicios.remainder(7, 2));
    }
    
    @Test
    public void test12(){
        assertEquals(3, Ejercicios.remainder(3, 4));
    }
    
    @Test
    public void test13(){
        assertEquals(-9, Ejercicios.remainder(-9, 45));
    }
    
    @Test
    public void test14(){
        assertEquals(0, Ejercicios.remainder(5, 5));
    }
}
