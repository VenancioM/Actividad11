
package metodos;

public class Ejercicios {
   
    //Ejercicio: Return the Next Number from the Integer Passed
    //Lenguaje usado: Java
    //Este tipo de actividades hace que se agilicen nuestras habilidades como programadores
    public static int addition(int num){
        return num+1;
    }
    
    //Ejercicio Equal
    public static boolean isEqual(int num1, int num2){
        if(num1 == num2){
            return true;
        }else{
            return false;
        }
    }
    
    
    //Ejercicio Residuo
    public static int remainder(int a, int b){
        return a%b;
    }
    
    
}
